package Testes;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pages.Cadastrar;
import pages.Login;
import pages.Metodos;

public class Testes {
	Metodos metodo = new Metodos();
	Cadastrar cadastrar = new Cadastrar();
	Login login = new Login();

	@Given("^que eu esteja no site \"([^\"]*)\"$")
	public void que_eu_esteja_no_site(String arg1) throws Throwable {
		metodo.abrirNavegador(arg1);
	}

	@When("^Preencho o Formulario de Cadastro Corretamente\\.$")
	public void preencho_o_Formulario_de_Cadastro_Corretamente() throws Throwable {
		cadastrar.AcessarFormularioDeCadastro();
		cadastrar.PreencherDadosObrigatorios();

	}

	@Then("^valido se minha conta foi criada com sucesso\\.$")
	public void valido_se_minha_conta_foi_criada_com_sucesso() throws Throwable {
		cadastrar.validar();
	}

	@When("^Preencho o Formulario de Login$")
	public void preencho_o_Formulario_de_Login() throws Throwable {
		login.Logar();

	}

	@Then("^valido se minha conta foi logada com sucesso$")
	public void valido_se_minha_conta_foi_logada_com_sucesso() throws Throwable {

	}

}
