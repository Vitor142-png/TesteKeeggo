package elementos;

import org.openqa.selenium.By;

public class Elementos {

	private By clicarMenuUser = By.id("menuUser");
	private By clicarCadastrar = By.xpath("/html/body/login-modal/div/div/div[3]/a[2]");
	private By escreverUserNameRegister = By.name("usernameRegisterPage");
	private By escreverEmail = By.name("emailRegisterPage");
	private By escreverPassword = By.name("passwordRegisterPage");
	private By confirmarPassword = By.name("confirm_passwordRegisterPage");
	private By clicarConcordaComCondicoes = By.name("i_agree");
	private By clicarRegistro = By.id("register_btnundefined");
	private By validarCadastro = By.xpath("//*[@id=\"menuUserLink\"]/span[text()='Vitorino06']");
	private By escreverUserNam = By.name("username");
	private By escreverSenha = By.name("password");
	private By clicarSignIn = By.id("sign_in_btnundefined");
	

	public By getClicarMenuUser() {
		return clicarMenuUser;
	}

	public By getClicarCadastrar() {
		return clicarCadastrar;
	}

	public By getEscreverPassword() {
		return escreverPassword;
	}

	public By getConfirmarPassword() {
		return confirmarPassword;
	}

	public By getEscreverUserName() {
		return escreverUserNameRegister;
	}

	public By getEscreverEmail() {
		return escreverEmail;
	}

	public By getClicarConcordaComCondicoes() {
		return clicarConcordaComCondicoes;
	}

	public By getClicarRegistro() {
		return clicarRegistro;
	}

	public By getValidarCadastro() {
		return validarCadastro;
	}

	public By getEscreverUserNam() {
		return escreverUserNam;
	}

	public By getEscreverSenha() {
		return escreverSenha;
	}

	public By getClicarSignIn() {
		return clicarSignIn;
	}

}
