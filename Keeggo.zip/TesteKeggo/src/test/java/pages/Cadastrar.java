package pages;

import elementos.Elementos;

public class Cadastrar {
	Metodos metodo = new Metodos();
	Elementos elemento = new Elementos();

	public void AcessarFormularioDeCadastro() throws Exception {
		metodo.clicar(elemento.getClicarMenuUser());
		metodo.esperaExplicita(2000);
		metodo.clicar(elemento.getClicarCadastrar());
		

	}

	
	public void PreencherDadosObrigatorios() throws Exception {
		metodo.escrever(elemento.getEscreverUserName(), "Vitorino06");
		metodo.escrever(elemento.getEscreverEmail(), "vitorino6@gmail.com");
		metodo.escrever(elemento.getEscreverPassword(), "98752015Aa");
		metodo.escrever(elemento.getConfirmarPassword(), "98752015Aa");
		metodo.clicar(elemento.getClicarConcordaComCondicoes());
		metodo.clicar(elemento.getClicarRegistro());
		metodo.esperar();
		
		
	}
	
	public void validar() throws Exception {
		metodo.ScreenShot("CT-01");
		metodo.validarTexto(elemento.getValidarCadastro(), "Vitorino06");
		
	}

}
