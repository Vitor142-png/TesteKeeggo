package pages;

import static org.junit.Assert.assertEquals;

import java.io.File;

import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.hamcrest.Matcher;
import org.hamcrest.core.StringContains;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;

public class Metodos extends Browser {

	public void escrever(By elemnto, String texto) {
		adriver().findElement(elemnto).sendKeys(texto);

	}

	public void clicar(By elemento) {
		adriver().findElement(elemento).click();

	}

	public void ScreenShot(String nomeScr) throws Exception {
		TakesScreenshot scrShot = ((TakesScreenshot) adriver());
		File scrFile = scrShot.getScreenshotAs(OutputType.FILE);
		File destFile = new File("./Evidencias/" + nomeScr + ".png");
		FileUtils.copyFile(scrFile, destFile);
	}

	public void validarTexto(By elemento, String textoEsperado) {
		try {

			WebElement texto = adriver().findElement(elemento);
			String textoCapturado = texto.getText();
			assertEquals(textoEsperado, textoCapturado);
		} catch (Exception e) {
			System.err.println("-------- error ao validar texto -------" + e.getMessage());
		}

	}

	public void esperar() throws InterruptedException {
		adriver().manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);

	}

	public void esperaExplicita(int tempo) throws Exception {
		Thread.sleep(2000);

	}

	public void fecharAba() {

		adriver().switchTo().window(null);

	}

	public void fecharNavegador() {

		adriver().quit();

	}

	public void voltarPaginaAnterior() {
		adriver().navigate().back();

	}

	public void clickDiferenciado(By elementos) {
		adriver().findElement(elementos).click();

	}

}
