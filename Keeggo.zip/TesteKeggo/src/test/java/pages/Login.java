package pages;

import elementos.Elementos;

public class Login {
	Metodos metodo = new Metodos();
	Elementos elemento = new Elementos();

	public void Logar() throws Exception {
		metodo.clicar(elemento.getClicarMenuUser());
		metodo.esperar();
		metodo.escrever(elemento.getEscreverUserNam(), "Vitorino06");
		metodo.escrever(elemento.getEscreverSenha(), "98752015Aa");
		metodo.esperaExplicita(8000);
		metodo.clicar(elemento.getClicarSignIn());

	}

	public void validarLogin() throws Exception {
		metodo.ScreenShot("CT-02");
		metodo.validarTexto(elemento.getValidarCadastro(), "Vitorino06");
		
	}
}
