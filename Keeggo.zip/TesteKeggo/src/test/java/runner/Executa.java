package runner;

import org.junit.AfterClass;
import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import pages.Browser;

//utilizei o runwith para executar o cucumber
@RunWith(Cucumber.class) 



//aqui estao os caminhos onde serão executados o runner
@CucumberOptions(
		
		// caminho da feature
		features = "src/test/resources/Features",

		// indica onde estão implementados os gherkins
		glue = "Testes",

		// indica o que deve ser executado
		tags = "@Executa",

		// verifica se esta faltando implementar algum codigo
		dryRun = false,

		// formata exibicao dos caracteres especiais
		monochrome = true

		
)

public class Executa extends Browser {

	// metodo para fechar o browser
	@AfterClass
	public static void fecharPagina() {
		//adriver().quit();

	}

}
